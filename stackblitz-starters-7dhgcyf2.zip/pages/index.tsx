// pages/index.tsx
import Head from "next/head";

export default function Home() {
  return (
    <div className="min-h-screen bg-[#1f1449] text-white font-sans">
      <Head>
        <title>Medya Rehberim - Takip Etme, Yön Ver!</title>
        <meta
          name="description"
          content="Sosyal medya danışmanlığı, dijital hizmetler ve daha fazlası."
        />
      </Head>

      <header className="text-center py-10">
        <div className="flex justify-center mb-6">
          <img src="/logo.png" alt="Medya Rehberim Logo" width={180} height={90} />
        </div>
        <h1 className="text-4xl font-bold">TAKİP ETME, YÖN VER!</h1>
        <p className="mt-2 text-lg">Danışmanlık ve Sosyal Medya Paketleri</p>
        <button className="mt-4 bg-orange-500 hover:bg-orange-600 text-white font-semibold py-2 px-6 rounded">
          Hizmetlerimiz
        </button>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-10 grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
        {/* Instagram */}
        <div className="bg-white text-black p-6 rounded-xl shadow-md text-center hover:scale-105 transition-transform duration-300">
          <img src="/icons/instagram.png" alt="Instagram" width={60} height={60} className="mx-auto mb-4" />
          <h3 className="text-xl font-bold">Instagram Takipçi</h3>
          <p className="mt-2">Instagram takipçi paketlerimizle kitlenizi büyütün.</p>
          <button className="mt-4 bg-orange-500 hover:bg-orange-600 text-white py-2 px-4 rounded">
            İncele
          </button>
        </div>

        {/* TikTok */}
        <div className="bg-white text-black p-6 rounded-xl shadow-md text-center hover:scale-105 transition-transform duration-300">
          <img src="/icons/tiktok.png" alt="TikTok" width={60} height={60} className="mx-auto mb-4" />
          <h3 className="text-xl font-bold">TikTok Takipçi</h3>
          <p className="mt-2">TikTok takipçi paketlerimizle görünürlüğünüzü artırın.</p>
          <button className="mt-4 bg-orange-500 hover:bg-orange-600 text-white py-2 px-4 rounded">
            İncele
          </button>
        </div>

        {/* YouTube */}
        <div className="bg-white text-black p-6 rounded-xl shadow-md text-center hover:scale-105 transition-transform duration-300">
          <img src="/icons/youtube.png" alt="YouTube" width={60} height={60} className="mx-auto mb-4" />
          <h3 className="text-xl font-bold">YouTube Takipçi</h3>
          <p className="mt-2">YouTube takipçi paketlerimizle abone sayınızı yükseltin.</p>
          <button className="mt-4 bg-orange-500 hover:bg-orange-600 text-white py-2 px-4 rounded">
            İncele
          </button>
        </div>
      </main>

      <footer className="text-center mt-10 text-sm opacity-70">
        © 2025 MedyaRehberim. Tüm hakları saklıdır.
      </footer>
    </div>
  );
}
